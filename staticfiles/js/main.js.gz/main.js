// ---------------------------------------------------------------------------
// Open a register on the date a link asked for.
//
// Every transaction register opens on today, or on the last week. A link to a
// particular record - from the Change Requests page, say - would therefore land
// on a list that does not contain it, which reads as the record having been
// deleted rather than as a filter hiding it.
//
// A link may carry ?from_date=&to_date=; if it does, this writes them into the
// page's own date inputs and presses its own filter button, so the register
// loads exactly the way it would if someone had typed the dates in.
//
// It may also carry ?record=, the number of the one row that was asked for.
// That goes into the register's own search box rather than being filtered
// invisibly: the reader can see why a list of one is a list of one, and clear
// it to get the rest of the day back.
//
// Ordering is the whole difficulty. A register sets its defaults inside
// jQuery's ready callback, and when the document is already complete by the
// time that callback is registered - which it is, since these scripts sit at
// the foot of the page - jQuery defers it. So a plain load listener runs first
// and is then overwritten by the very defaults it meant to replace. Waiting a
// turn of the event loop after load puts this behind that queue.
//
// Thirty-two registers share these control ids (#from-date, #to-date and either
// #filter-submit or #search-btn), which is what makes one handler here better
// than thirty-two copies of four lines.
// ---------------------------------------------------------------------------
window.addEventListener('load', function () {
  const params = new URLSearchParams(window.location.search);
  const from = params.get('from_date');
  const to = params.get('to_date');
  if (!from && !to) return;

  setTimeout(function () {
    const fromEl = document.getElementById('from-date');
    const toEl = document.getElementById('to-date');
    if (!fromEl && !toEl) return;            // not a register; nothing to do

    if (fromEl && from) fromEl.value = from;
    if (toEl && to) toEl.value = to;

    // The page's own button, so the register reloads exactly as it would if
    // someone had typed the dates and pressed it.
    const reload = document.getElementById('filter-submit')
                || document.getElementById('search-btn');
    if (reload) reload.click();

    const record = params.get('record');
    if (record) showOnlyRecord(record);

    // Several records at once — the Duplicate Entries page sends the numbers
    // of one finding so the register opens on exactly those rows.
    const records = params.get('records');
    if (records) showOnlyRecords(records.split(',').filter(Boolean));
  }, 0);
});

// Put a record number into the register's own DataTables search box.
//
// The wait is the awkward part. Pressing the filter button starts a fetch, and
// these registers destroy and rebuild their table when it returns, which would
// throw away a search applied too early. So this waits until the row is
// actually on screen before typing into the box - at which point the table it
// is typing into is certainly the final one.
//
// If the row never appears the search is left alone: showing the day's list is
// a better answer than an empty table filtered by a number that is not there.
function showOnlyRecord(record) {
  let attempts = 0;
  (function tick() {
    const input = document.querySelector('.dataTables_filter input');
    const body = document.querySelector('table tbody');
    if (input && body && body.textContent.includes(record)) {
      input.value = record;
      // DataTables listens for these rather than for a value assignment.
      input.dispatchEvent(new Event('input', { bubbles: true }));
      input.dispatchEvent(new Event('keyup', { bubbles: true }));
      return;
    }
    if (++attempts < 40) setTimeout(tick, 150);   // give up after ~6 seconds
  })();
}

// Show only the records named, however many.
//
// The single-record version above types into the search box, which cannot
// express "this one or that one" — the box searches for one string. So this
// goes through the DataTables API instead, where a search can be a regular
// expression, and asks for the numbers joined by alternation.
//
// The box is filled in afterwards so the page does not look unfiltered, but
// without firing the events that would make DataTables re-read it as a plain
// string and throw the regex away.
//
// Same wait as the single version, and the same reason: a register rebuilds
// its table when its filter returns, and a search applied before that is lost.
function showOnlyRecords(records) {
  if (!records.length) return;
  if (records.length === 1) return showOnlyRecord(records[0]);

  const pattern = records
    .map(function (r) { return r.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); })
    .join('|');
  let attempts = 0;
  (function tick() {
    const body = document.querySelector('table tbody');
    const ready = body && records.some(function (r) { return body.textContent.includes(r); });
    if (ready && $.fn.dataTable) {
      $.fn.dataTable.tables({ api: true }).search(pattern, true, false).draw();
      const input = document.querySelector('.dataTables_filter input');
      if (input) input.value = records.join(' , ');
      return;
    }
    if (++attempts < 40) setTimeout(tick, 150);
  })();
}

// ---------------------------------------------------------------------------
// The local calendar day as YYYY-MM-DD.
//
// Formatting straight from toISOString gives the UTC day. India runs 5:30
// ahead, so the UTC date does not turn over until 05:30 local: between
// midnight and 05:30 it still names yesterday, and a form opened at 5am on a
// farm prefilled the previous date. Shifting by the zone's own offset first
// keeps the browser's date, which is the one the person is working in.
//
// Exposed globally because ~50 pages need it; `date` is optional and defaults
// to now.
// ---------------------------------------------------------------------------
// ---------------------------------------------------------------------------
// A date as DD-MM-YYYY, which is how this business writes one.
//
// The registers printed whatever the API sent, which is ISO (2026-07-21), so a
// grid disagreed with its own filter boxes and with every server-rendered date
// on the site. One helper rather than twenty copies of the same three lines.
//
// Anything that is not an ISO date comes back unchanged but escaped, since
// these values are dropped straight into a template string.
// ---------------------------------------------------------------------------
window.fmtDate = function (value) {
  if (value === null || value === undefined || value === "") return "";
  const text = String(value);
  const iso = text.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (iso) return iso[3] + "-" + iso[2] + "-" + iso[1];
  return text.replace(/[&<>"]/g, function (ch) {
    return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[ch];
  });
};

// ---------------------------------------------------------------------------
// Every register sorts its Date column as plain text by default, and
// fmtDate's own DD-MM-YYYY is exactly the format text-sorting gets wrong —
// "02-10-2026" reads as earlier than "29-09-2026" because "0" < "2". A grid
// with `order: [[0, "desc"]]` on a fmtDate'd column looked "almost sorted"
// (right within a month, wrong across one) rather than obviously broken,
// which is why it went unnoticed on page after page. Registered once, here,
// rather than patched per grid: every table gets correct date ordering for
// free, including ones that never think about sorting at all.
// ---------------------------------------------------------------------------
if (window.jQuery && jQuery.fn.dataTable) {
  jQuery.fn.dataTable.ext.type.detect.unshift(function (data) {
    return (typeof data === "string" && /^\d{2}-\d{2}-\d{4}$/.test(data.trim()))
      ? "date-dd-mm-yyyy" : null;
  });
  jQuery.fn.dataTable.ext.type.order["date-dd-mm-yyyy-pre"] = function (data) {
    if (!data) return 0;
    const parts = String(data).trim().split("-");
    return parseInt(parts[2] + parts[1] + parts[0], 10);
  };
}

window.localDay = function (date) {
  const d = date ? new Date(date) : new Date();
  if (isNaN(d.getTime())) return "";
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000)
    .toISOString().slice(0, 10);
};

// Month / Year shortcuts: a Year select marked data-period-year, naming its
// Month select and the From / To inputs it fills. Year lists the calendar
// years the financial years in Account > Financial Year cover.
//   Year alone  -> that whole year, 1 Jan to 31 Dec.
//   Month + Year -> that month of that year.
//   Month alone -> that month this year.
// Loading is left to the page's Submit, as for the dates themselves. Typing a
// date, or Clear, puts both back to All: they no longer describe the range.
$(function () {
  document.querySelectorAll("select[data-period-year]").forEach(function (year) {
    const month = document.querySelector(year.dataset.periodMonth);
    const from = document.querySelector(year.dataset.periodFrom);
    const to = document.querySelector(year.dataset.periodTo);
    if (!month || !from || !to) return;

    $(month).add(year).on("change", function () {
      const m = parseInt(month.value, 10);
      const picked = parseInt(year.value, 10);
      if (!m && !picked) return;
      const y = picked || new Date().getFullYear();
      from.value = localDay(new Date(y, m ? m - 1 : 0, 1));
      to.value = localDay(m ? new Date(y, m, 0) : new Date(y, 11, 31));
    });
    const reset = function () { $(month).add(year).val("").trigger("change.select2"); };
    $(from).add(to).on("input", reset);
    $("#filter-clear").on("click", reset);
  });
});

// ---------------------------------------------------------------------------
// Register search: spaces mean "and", commas mean "or".
//
// DataTables' own smart search already ands the words you type across the
// row -- "green valley 990" finds the one sale that has both. What it cannot
// do is ask for two records at once: "2399,2398" looks for a row containing
// that whole string and finds nothing.
//
// A comma now separates alternatives. Each alternative keeps the and
// behaviour, so "green valley 990, abhinav" means (green and valley and 990)
// or (abhinav). Without a comma nothing changes: the box hands the term
// straight to DataTables as before.
// ---------------------------------------------------------------------------
(function ($) {
  // The test harness loads this file against a jQuery stub that carries
  // `dataTable.defaults` and nothing else, so every piece used here is
  // checked for rather than assumed.
  if (!$ || !$.fn || !$.fn.dataTable || !$.fn.dataTable.ext
      || !$.fn.dataTable.ext.search || !$.fn.dataTable.Api) return;

  // One filter for every table on the site; it stands aside unless that
  // table's box is holding a comma.
  $.fn.dataTable.ext.search.push(function (settings, searchData) {
    var groups = settings.__anyOf;
    if (!groups || !groups.length) return true;
    var row = searchData.join(" ").toLowerCase();
    return groups.some(function (words) {
      return words.every(function (word) { return row.indexOf(word) !== -1; });
    });
  });

  function parse(value) {
    return value.split(",")
      .map(function (part) { return part.trim().toLowerCase(); })
      .filter(Boolean)
      .map(function (part) { return part.split(/\s+/); });
  }

  $(document).on("init.dt", function (e, settings) {
    if (e.namespace !== "dt") return;
    var api = new $.fn.dataTable.Api(settings);
    var input = $(settings.nTableWrapper).find(".dataTables_filter input");
    if (!input.length) return;

    // Words, not numbers: a placeholder of "2399, 2398" reads as a value
    // somebody already typed rather than as a hint about the box.
    input.attr("placeholder", "comma for either");
    input.attr("title", "Spaces narrow the search; a comma asks for either");

    // DataTables' own handler would search for the comma string itself, so
    // the box is rebound rather than listened to alongside.
    input.off(".DT").on("input.bimsSearch", function () {
      var value = this.value;
      if (value.indexOf(",") === -1) {
        settings.__anyOf = null;
        api.search(value).draw();
        return;
      }
      settings.__anyOf = parse(value);
      // The alternatives are ours to apply; DataTables' own term would fight
      // them, so it is cleared while a comma is in the box.
      api.search("").draw();
    });
  });
})(jQuery);

// ---------------------------------------------------------------------------
// Registers on a phone: the columns stay and the table scrolls sideways.
//
// DataTables Responsive folds the spare columns into a row you open instead.
// On a thirteen-column register that leaves four columns and nine numbers
// behind a chevron -- Farm, Batch, Birds, Net Wt., Avg Wt., Rate, Amount --
// which is most of what a register is read for. Swiping a wide table is the
// gesture the module bar and the page tabs already use on that screen.
//
// `responsive: true` is written into sixty-seven registers one by one, so it
// cannot be turned off from the defaults: this takes it out of the options as
// each table is built, and only where the screen is narrow. Wider screens are
// untouched, and so is every other option the page passed.
// ---------------------------------------------------------------------------
(function ($) {
  if (!$ || !$.fn || !$.fn.dataTable || !window.matchMedia) return;
  var narrow = window.matchMedia("(max-width: 991.98px)");

  ["DataTable", "dataTable"].forEach(function (name) {
    var original = $.fn[name];
    if (typeof original !== "function") return;
    function patched(options) {
      if (narrow.matches && options && options.responsive) {
        options = $.extend({}, options, { responsive: false });
      }
      return original.apply(this, [options].concat(
        Array.prototype.slice.call(arguments, 1)));
    }
    // The constructor carries the API on itself (defaults, ext, Api, version),
    // and the rest of this file and every page reads them from there.
    $.extend(patched, original);
    patched.prototype = original.prototype;
    $.fn[name] = patched;
  });
})(jQuery);

// Applied to every DataTable on the site as soon as this script runs (i.e.
// before any page's own $(document).ready() handler calls .DataTable()),
// since defaults must be set before initialization, not inside a ready
// callback of our own - ready handlers fire in registration order, and
// individual pages register theirs earlier in the document than this file.
$.extend(true, $.fn.dataTable.defaults, {
  dom: "Blfrtip",
  buttons: [
    { extend: "copyHtml5", exportOptions: { columns: "th:not(:last-child)" } },
    { extend: "csvHtml5", exportOptions: { columns: "th:not(:last-child)" } },
    { extend: "excelHtml5", exportOptions: { columns: "th:not(:last-child)" } },
    { extend: "pdfHtml5", exportOptions: { columns: "th:not(:last-child)" }, orientation: "landscape" },
    { extend: "print", exportOptions: { columns: "th:not(:last-child)" } },
    "colvis",
  ],
});

// ---------------------------------------------------------------------------
// A Select2 panel that would hang past the right edge of the window.
//
// The panel is deliberately wider than its field -- 300px, so a long item
// name sits on one line -- but Select2 pins it to the field's left edge. A
// field near the right of the screen therefore pushes the panel off it, and
// the document grows a sideways scrollbar that has nothing to do with the
// page's own content. Nudged back inside, once, as it opens.
// ---------------------------------------------------------------------------
(function ($) {
  var MARGIN = 8;

  function keepInside() {
    // The panel has the width; its container -- a zero-width wrapper that
    // Select2 appends to the body -- has the `left` that moves it. Measuring
    // the container instead of the panel finds no overflow and does nothing.
    var panel = document.querySelector(".select2-container--open .select2-dropdown");
    if (!panel) return;
    var container = panel.parentElement;
    var over = panel.getBoundingClientRect().right
             - (document.documentElement.clientWidth - MARGIN);
    if (over <= 0) return;
    container.style.left = (parseFloat(container.style.left || "0") - over) + "px";
  }

  $(document).on("select2:open", function () {
    // After Select2 has placed it: it sets left/top itself on open.
    window.requestAnimationFrame(keepInside);
  });
})(jQuery);

// ---------------------------------------------------------------------------
// Column alignment, mirrored from the header onto the body.
//
// The design system aligns by data type: quantities, rates and amounts right,
// dates and statuses centred, everything else left. Marking that up per cell is
// impossible for most of these grids because their rows are built in JS — so
// the header carries the intent and this copies it down, once per render.
// ---------------------------------------------------------------------------
(function ($) {
  var ALIGN = ["ds-num", "ds-mid"];

  function mirror(table) {
    var $table = $(table);
    if (!$table.length) return;
    var classes = $table.find("thead th").map(function () {
      var th = this;
      return ALIGN.filter(function (c) { return th.classList.contains(c); }).join(" ");
    }).get();
    if (!classes.some(Boolean)) return;
    $table.find("tbody tr").each(function () {
      $(this).children("td").each(function (i) {
        if (classes[i]) this.className = (this.className + " " + classes[i]).trim();
      });
    });
  }

  $(document).on("init.dt draw.dt", function (e, settings) {
    mirror(settings ? settings.nTable : null);
  });
  $(function () { $("table.ds-grid, table.ds-entry").each(function () { mirror(this); }); });

  // Grids that render their own rows outside DataTables can ask for it.
  window.dsAlignColumns = mirror;
})(jQuery);

// ---------------------------------------------------------------------------
// Landing from the dashboard's global search: a record hit links to its list
// page carrying ?find=<term>. Seed every DataTable on that page with the term
// so the row the user actually picked is filtered to the top on arrival,
// instead of dropping them at the top of an unfiltered list.
//
// Registered as a delegated init.dt here (rather than an initComplete default)
// because $.extend replaces rather than merges functions - a page defining its
// own initComplete would silently drop ours.
// ---------------------------------------------------------------------------
(function ($) {
  var term = new URLSearchParams(window.location.search).get("find");
  if (!term) return;
  $(document).on("init.dt", function (e, settings) {
    var api = new $.fn.dataTable.Api(settings);
    if (api.search()) return;   // the page set its own filter - leave it alone
    var box = $(settings.nTableWrapper).find(".dataTables_filter input");
    if (box.length) box.val(term);
    api.search(term).draw();
  });
})(jQuery);

// ---------------------------------------------------------------------------
// Global searchable dropdowns: every select.form-select on the site becomes a
// searchable Select2 (Bootstrap 5 theme), including selects added to the DOM
// later (dynamic table rows, generated modals). Opt out with data-no-search.
// ---------------------------------------------------------------------------
(function ($) {
  function searchableSelect(el) {
    const $el = $(el);
    // Multi-selects are included. Left native they render as a short scrolling
    // box that shows two or three rows of a list that may run to hundreds, with
    // no search and with ctrl-click as the only way to pick a second item —
    // which is not discoverable and is impossible on a touch screen. `size` is
    // still respected on single selects, where it is an explicit ask for a list.
    if (!$el.is('select.form-select')) return;
    if (!el.multiple && el.size > 1) return;
    if ($el.is('[data-no-search]') || $el.hasClass('select2-hidden-accessible')) return;
    if ($el.closest('.dataTables_length').length) return; // keep DataTables' page-size menu native
    const small = $el.hasClass('form-select-sm');
    // Reparent onto .modal-content (not .modal) when inside a modal: Bootstrap
    // gives .modal-content `position: relative`, which is the containing
    // block Select2's offset()-based math expects. .modal itself is
    // `position: fixed` (viewport-anchored), so children absolutely
    // positioned against it land wherever the page happens to be scrolled —
    // the dropdown appears "anywhere" in the modal instead of under the field.
    const $modalContent = $el.closest('.modal-content');
    $el.select2({
      theme: 'bootstrap-5',
      width: el.style.width ? 'style' : '100%',
      selectionCssClass: small ? 'select2--small' : '',
      dropdownCssClass: small ? 'select2--small' : '',
      dropdownParent: $modalContent.length ? $modalContent : $(document.body),
      // What an empty box means is the field's business, not this helper's:
      // on some forms nothing selected means "everything", on others it means
      // "none". Whoever knows says so with data-placeholder.
      placeholder: $el.data('placeholder') || null,
      // Picking several is the normal case on a multi-select, and closing the
      // list after each one makes choosing four branches four journeys.
      closeOnSelect: !el.multiple,
    });
    // Select2 raises only jQuery events; re-dispatch native input/change so
    // vanilla listeners (onchange=..., addEventListener) keep working.
    $el.on('select2:select select2:unselect select2:clear', function () {
      this.dispatchEvent(new Event('input', { bubbles: true }));
      this.dispatchEvent(new Event('change', { bubbles: true }));
    });
    // Pages show/hide the native select (d-none, .hide()); the rendered
    // Select2 box must follow, or hidden selects appear as duplicate boxes.
    const container = $el.next('.select2-container');
    const syncVisibility = function () {
      container.toggleClass('d-none',
        el.classList.contains('d-none') || el.style.display === 'none');
    };
    syncVisibility();
    new MutationObserver(syncVisibility)
      .observe(el, { attributes: true, attributeFilter: ['class', 'style'] });
  }
  window.searchableSelect = searchableSelect;

  /* A list always opens downward, and is always fully on screen.
   *
   * Select2 flips its list above the control when the window has less than
   * the list's height below it. On an entry sheet that is most of the rows:
   * the list covers the lines above the one being filled in, which are the
   * lines somebody is reading to fill it. The browser's own dropdown never
   * does this, which is why the lifting supervisor column opted out of
   * Select2 altogether for a while rather than put up with it.
   *
   * So the placement is taken back. `_positionDropdown` is wrapped rather
   * than replaced: Select2 keeps calling it on scroll and resize, and each
   * time it is allowed to do its own arithmetic before the answer is
   * overruled. Only the direction is changed, and only when it chose above.
   *
   * Forcing it down would push the list off the bottom of a window with no
   * room, so `select2:open` scrolls the page far enough to bring it back —
   * which is the part that makes this an improvement rather than a trade.
   */
  const amd = $.fn.select2 && $.fn.select2.amd;
  if (amd && typeof amd.require === 'function') {
    try {
      const AttachBody = amd.require('select2/dropdown/attachBody');
      const position = AttachBody.prototype._positionDropdown;
      AttachBody.prototype._positionDropdown = function () {
        position.apply(this, arguments);
        // Select2 calls this again on every scroll and resize while a list is
        // open, so a throw in here would break the list mid-use rather than
        // fail once at startup. Whatever goes wrong, Select2's own placement
        // has already been applied above and stands.
        try {
          this._placeBelow();
        } catch (e) { /* leave Select2's answer alone */ }
      };

      AttachBody.prototype._placeBelow = function () {
        if (!this.$container.hasClass('select2-container--above')) return;

        // The same offsets Select2 works in: the dropdown is positioned
        // against its parent, which is the body unless the field is in a
        // modal.
        let $parent = this.$dropdownParent;
        if ($parent.css('position') === 'static') $parent = $parent.offsetParent();
        const parent = $parent.offset() || { top: 0, left: 0 };
        const offset = this.$container.offset();

        this.$dropdown.removeClass('select2-dropdown--above')
                      .addClass('select2-dropdown--below');
        this.$container.removeClass('select2-container--above')
                       .addClass('select2-container--below');
        this.$dropdownContainer.css({
          top: offset.top + this.$container.outerHeight(false) - parent.top,
          left: offset.left - parent.left,
        });
      };
    } catch (e) {
      // Select2 changed its module layout: leave the placement alone rather
      // than half-apply it. The list flips as it used to, which is the
      // behaviour this replaced and not a broken page.
    }
  }

  /* Fit the list into the room below, rather than move the page to make room.
   *
   * Scrolling the page on open was the first attempt and it is not safe:
   * Select2 opens on mousedown, so the page would slide out from under the
   * pointer mid-press, and the mouseup at the end of an ordinary press could
   * land on something else — which Select2 reads as a click outside and
   * closes on. A synthetic click never shows it, because its down and up are
   * in the same tick.
   *
   * Said plainly: that failure was reasoned from how the events are ordered,
   * not observed here. It was reported from a browser and never reproduced
   * in a harness. What is certain is that capping the list needs no page
   * movement at all, so the question cannot arise.
   */
  const LIST_FLOOR = 120;   // below this a list is not worth opening at all
  $(document).on('select2:open', function () {
    const dropdown = document.querySelector('.select2-container--open .select2-dropdown');
    const results = dropdown && dropdown.querySelector('.select2-results__options');
    if (!results) return;
    // Whatever the dropdown spends on the search box and its own padding has
    // to come out of the room before the list gets what is left.
    const chrome = dropdown.offsetHeight - results.offsetHeight;
    const room = document.documentElement.clientHeight
      - dropdown.getBoundingClientRect().top - 8;
    results.style.maxHeight = Math.max(LIST_FLOOR, room - chrome) + 'px';
  });

  // Keep the rendered Select2 in sync when code assigns values directly —
  // el.value = x, $el.val(x), form.reset() — none of which fire 'change'.
  // 'change.select2' updates Select2's display without running app handlers.
  const nativeValue = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, 'value');
  Object.defineProperty(HTMLSelectElement.prototype, 'value', {
    configurable: true,
    get: nativeValue.get,
    set: function (v) {
      nativeValue.set.call(this, v);
      if (this.classList.contains('select2-hidden-accessible')) $(this).trigger('change.select2');
    },
  });
  const jqueryVal = $.fn.val;
  $.fn.val = function () {
    const result = jqueryVal.apply(this, arguments);
    if (arguments.length) this.filter('select.select2-hidden-accessible').trigger('change.select2');
    return result;
  };
  const nativeReset = HTMLFormElement.prototype.reset;
  HTMLFormElement.prototype.reset = function () {
    nativeReset.apply(this, arguments);
    $(this).find('select.select2-hidden-accessible').trigger('change.select2');
  };
  $(document).on('reset', 'form', function (e) {
    setTimeout(function () {
      $(e.target).find('select.select2-hidden-accessible').trigger('change.select2');
    });
  });

  $(function () {
    $('select.form-select').each(function () { searchableSelect(this); });
    new MutationObserver(function (mutations) {
      mutations.forEach(function (m) {
        m.addedNodes.forEach(function (node) {
          if (node.nodeType !== 1) return;
          if (node.matches('select.form-select')) searchableSelect(node);
          node.querySelectorAll('select.form-select').forEach(searchableSelect);
        });
      });
    }).observe(document.body, { childList: true, subtree: true });
  });
})(jQuery);

// ---------------------------------------------------------------------------
// Transaction dates cannot be in the future.
//
// A transaction dated ahead of today corrupts everything read as-of a date —
// age, opening stock, live-bird counts, ledger balances — and there is no
// legitimate reason to file one. Applied here rather than per form so every
// transaction page gets it, including rows built in JavaScript after load.
//
// Scope is deliberately narrow: only a date input whose id/name is exactly
// "date", or that carries a "date" class (this codebase's row convention).
// Scheduling fields have their own names — hatch_date, setting_date,
// transfer_date, effective_from, agreement dates, financial-year bounds — and
// those are legitimately in the future, so they are left alone. Any field can
// opt out with data-allow-future.
// ---------------------------------------------------------------------------
(function () {
  const today = window.localDay;

  function isTransactionDate(el) {
    if (el.type !== 'date' || el.hasAttribute('data-allow-future')) return false;
    return el.id === 'date' || el.name === 'date' || el.classList.contains('date');
  }

  function guard(el) {
    if (!isTransactionDate(el) || el.dataset.futureGuarded) return;
    el.dataset.futureGuarded = '1';
    const max = today();
    // Only tighten: a page that already set its own max keeps it.
    if (!el.max || el.max > max) el.max = max;
    if (el.value && el.value <= max) el.dataset.lastGood = el.value;
  }

  function check(el) {
    if (!el.dataset.futureGuarded || !el.value) return;
    if (el.value > today()) {
      window.alert('Entry date cannot be later than today.');
      // Reverted, not clamped: clamping would leave a date nobody chose.
      el.value = el.dataset.lastGood || today();
    } else {
      el.dataset.lastGood = el.value;
    }
  }

  function scan(root) {
    if (root.nodeType !== 1) return;
    if (root.matches && root.matches('input[type="date"]')) guard(root);
    if (root.querySelectorAll) root.querySelectorAll('input[type="date"]').forEach(guard);
  }

  document.addEventListener('DOMContentLoaded', function () {
    scan(document.body);
    new MutationObserver(function (mutations) {
      mutations.forEach(function (m) { m.addedNodes.forEach(scan); });
    }).observe(document.body, { childList: true, subtree: true });
  });

  // Delegated so rows added later are covered without rebinding.
  document.addEventListener('change', function (e) {
    if (e.target && e.target.matches && e.target.matches('input[type="date"]')) check(e.target);
  }, true);
})();

// ---------------------------------------------------------------------------
// Shared UI helpers (design-system single source of truth). Pages currently
// copy-paste their own showToast()/escapeHtml() locally; those local defs still
// shadow these globals, so adding them here is non-breaking. New/refactored
// pages can drop their duplicates and call window.showToast / window.escapeHtml
// / window.bimsConfirm instead, keeping toast colours and confirm dialogs
// consistent site-wide and sourced from the CSS tokens.
// ---------------------------------------------------------------------------
(function () {
  // Solid token hexes (Toastify needs a colour string, not a CSS var).
  var TOAST_BG = {
    success: '#16a34a',
    danger:  '#dc2626',
    error:   '#dc2626',
    warning: '#d97706',
    info:    '#0891b2',
    primary: '#2563eb'
  };

  window.escapeHtml = window.escapeHtml || function (unsafe) {
    return (unsafe == null ? '' : String(unsafe))
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  };

  // How an open flock reads in a Batch dropdown. The number alone was enough
  // while a farm ran one flock at a time; several can now be open at once,
  // sharing a shed, and the placement date is what tells them apart.
  window.batchOptionLabel = window.batchOptionLabel || function (batch) {
    if (!batch || !batch.placed_on) { return (batch && batch.name) || ''; }
    // Split rather than parsed: "2026-09-14" as a Date is midnight UTC, which
    // reads as the day before in any timezone behind it.
    var parts = String(batch.placed_on).split('-');
    var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    var month = months[Number(parts[1]) - 1];
    if (parts.length < 3 || !month) { return batch.name; }
    return batch.name + ' · placed ' + Number(parts[2]) + ' ' + month;
  };

  window.showToast = window.showToast || function (type, message) {
    if (typeof Toastify === 'undefined') { return; }
    Toastify({
      text: message,
      duration: 3000,
      gravity: 'top',
      position: 'right',
      close: true,
      style: { background: TOAST_BG[type] || TOAST_BG.primary }
    }).showToast();
  };

  // Promise-based, on-brand replacement for native confirm(). Usage:
  //   window.bimsConfirm('Delete this record?').then(function (ok) { ... });
  // Falls back to native confirm() if Bootstrap's modal isn't available.
  window.bimsConfirm = function (message, opts) {
    opts = opts || {};
    var title = opts.title || 'Please confirm';
    var confirmText = opts.confirmText || 'Confirm';
    var cancelText = opts.cancelText || 'Cancel';
    var danger = opts.danger !== false; // default to destructive styling
    if (typeof bootstrap === 'undefined' || !bootstrap.Modal) {
      return Promise.resolve(window.confirm(message));
    }
    return new Promise(function (resolve) {
      var el = document.createElement('div');
      el.className = 'modal fade';
      el.setAttribute('tabindex', '-1');
      el.innerHTML =
        '<div class="modal-dialog modal-dialog-centered">' +
          '<div class="modal-content">' +
            '<div class="modal-header' + (danger ? ' danger-header' : '') + '">' +
              '<h5 class="modal-title"><i class="fas fa-' +
                (danger ? 'triangle-exclamation' : 'circle-question') + ' me-2"></i>' +
                window.escapeHtml(title) + '</h5>' +
              '<button type="button" class="btn-close" data-bs-dismiss="modal"></button>' +
            '</div>' +
            '<div class="modal-body" style="white-space:pre-line">' +
              window.escapeHtml(message) + '</div>' +
            '<div class="modal-footer">' +
              '<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">' +
                window.escapeHtml(cancelText) + '</button>' +
              '<button type="button" class="btn btn-' + (danger ? 'danger' : 'primary') +
                '" data-bims-confirm>' + window.escapeHtml(confirmText) + '</button>' +
            '</div>' +
          '</div>' +
        '</div>';
      document.body.appendChild(el);
      var modal = new bootstrap.Modal(el);
      var confirmed = false;
      el.querySelector('[data-bims-confirm]').addEventListener('click', function () {
        confirmed = true;
        modal.hide();
      });
      el.addEventListener('hidden.bs.modal', function () {
        el.remove();
        resolve(confirmed);
      });
      modal.show();
    });
  };
})();

$(document).ready(function () {
  $('#example').DataTable();

  // Initialise Bootstrap dropdowns, but NOT the nested submenu toggles —
  // those are driven manually (hover + tap) in main_top_navbar.html, and a
  // Bootstrap instance on them would fight that handler on touch devices.
  $('.dropdown-toggle').not('.dropdown-submenu > .dropdown-toggle').each(function () {
    new bootstrap.Dropdown(this);
  });

  // Close any open menu when tapping/clicking outside a dropdown.
  // Dropdowns live either in a .dropdown wrapper (navbar) or a .btn-group
  // (split/toolbar buttons) — treat both as "inside". DataTables' Buttons
  // collection (e.g. the "Column visibility" list) renders its own
  // .dropdown-menu-styled panel appended straight to <body>, detached from
  // any .dropdown/.btn-group ancestor, so it must be treated as "inside"
  // too — otherwise every checkbox click inside it reads as an outside
  // click and force-closes the list after one toggle.
  $(document).on('click', function (e) {
    if (!$(e.target).closest('.dropdown, .btn-group, .dt-button-collection').length) {
      $('.dropdown-menu').not('.dt-button-collection').removeClass('show');
    }
  });
});


/* ---------------------------------------------------------------------------
   Reverse geocoding — turn a GPS reading into a readable address.
   ---------------------------------------------------------------------------
   Used by Broiler > Transactions > Farm Location & Photos, so capturing a
   farm's pin also records where it is in words.

   Resolves to {display, state, district, area, postcode}, or null.

   OpenStreetMap's Nominatim needs no API key. It is best-effort by design: it
   is rate-limited and can be blocked or offline, so every caller must keep
   working when this resolves to null rather than treating a lookup failure as
   a failure to capture the location. The coordinates are the record; the
   address is a convenience on top.
   --------------------------------------------------------------------------- */
window.reverseGeocode = function (latitude, longitude) {
  const url = 'https://nominatim.openstreetmap.org/reverse?format=jsonv2'
            + '&lat=' + encodeURIComponent(latitude)
            + '&lon=' + encodeURIComponent(longitude)
            + '&zoom=18&addressdetails=1';
  const timeout = new Promise(function (resolve) { setTimeout(() => resolve(null), 8000); });
  const lookup = fetch(url, { headers: { 'Accept': 'application/json' } })
    .then(function (resp) { return resp.ok ? resp.json() : null; })
    .then(function (data) {
      if (!data || !data.display_name) return null;
      const a = data.address || {};
      // Nominatim names the same level differently by country and by how built
      // up the place is, so each part takes the first key that answers.
      return {
        display: data.display_name,
        state: a.state || '',
        district: a.state_district || a.county || a.district || '',
        area: a.suburb || a.village || a.town || a.city_district
              || a.neighbourhood || a.hamlet || a.city || '',
        postcode: a.postcode || '',
      };
    })
    .catch(function () { return null; });
  // Whichever settles first: a slow lookup must never hold up the form.
  return Promise.race([lookup, timeout]);
};


/* ---------------------------------------------------------------------------
   Dependent dropdowns — load one select's options from an endpoint.
   ---------------------------------------------------------------------------
   Replaces the hand-rolled "empty the select, then append in the AJAX
   callback" pattern, which double-fills whenever its change handler runs more
   than once: the empty happens straight away but both replies append later, so
   the list arrives twice. Select2 makes that routine — it raises its own
   jQuery change and the bridge above re-dispatches a native one, so a handler
   bound with .change() sees both.

   Two things make a repeated call harmless here: the list is rebuilt inside
   the reply rather than appended to, and each call takes a token so only the
   newest reply is allowed to render.

     loadOptions('#branch', url, {region_id: 3}, {list: 'branches', label: 'branch_name'})
   --------------------------------------------------------------------------- */
window.loadOptions = function (select, url, data, options) {
  options = options || {};
  const $select = window.jQuery(select);
  if (!$select.length) return window.jQuery.Deferred().resolve().promise();

  const token = ($select.data('optionsToken') || 0) + 1;
  $select.data('optionsToken', token);

  const placeholder = options.placeholder === undefined ? 'select' : options.placeholder;
  const valueKey = options.value || 'id';
  const labelKey = options.label || 'name';

  return window.jQuery.getJSON(url, data).then(function (response) {
    if ($select.data('optionsToken') !== token) return;   // a newer call won
    const rows = options.list ? (response[options.list] || []) : (response || []);

    $select.empty();
    if (placeholder !== null) {
      const first = document.createElement('option');
      first.value = '';
      first.textContent = placeholder;
      first.selected = true;
      if (options.placeholderDisabled !== false) first.disabled = true;
      $select.append(first);
    }
    rows.forEach(function (row) {
      const opt = document.createElement('option');
      opt.value = row[valueKey];
      // textContent, so a name with < or & cannot inject markup.
      opt.textContent = row[labelKey];
      $select.append(opt);
    });
    // Some endpoints pick for you - the scheme matching a batch, say - and name
    // the choice in the reply rather than the caller knowing it beforehand.
    // `selectedFrom` reads it from the response; `selected` still takes a value
    // the caller already holds.
    const chosen = options.selectedFrom ? response[options.selectedFrom] : options.selected;
    if (chosen) $select.val(chosen);
    if ($select.hasClass('select2-hidden-accessible')) $select.trigger('change.select2');
  });
};

/* ------------------------------------------------------------------ *
 * One save per press
 *
 * On a slow link a save looks like nothing happening, so the button gets
 * pressed again — and the second press files the record a second time. The
 * two copies carry the same details and either the same document number or
 * the next one, depending on whether the two requests read the counter in the
 * same instant or one after the other.
 *
 * Twenty-three of the forty forms already disabled their own button; the rest
 * did not, and none of them agreed on how. This does it once, for every form
 * on the site, the same way the searchable selects are applied globally rather
 * than page by page.
 *
 * It holds the button that started a write until that write comes back, then
 * releases it so a failed save can be retried. It does not make the save
 * idempotent — two presses that both reach the server are still two saves —
 * which is why it is a guard and not the whole answer.
 * ------------------------------------------------------------------ */
(function () {
  const WRITE = /^(POST|PUT|PATCH|DELETE)$/i;
  const inFlight = new WeakMap();
  let lastPressed = null;

  /* --- one save per form, not merely one per press -------------------
   *
   * Holding the button stops the second press. It does nothing about the
   * presses that never reach the button: a refresh and "resend", a second
   * tab, or a save that timed out on this side after the server had already
   * filed it. Those all arrive as a second, genuine request.
   *
   * So each form also carries a key, sent as a header — the same header the
   * phone's outbox uses, answered by the same middleware, so there is one
   * mechanism to understand rather than two. The server performs the first
   * request bearing a key and replays its answer to any other, which is what
   * makes a duplicate harmless rather than merely unlikely.
   *
   * The key belongs to the form, so every copy of one attempt shares it, and
   * is retired as soon as that attempt is answered — the next press is a new
   * intention, not a replay of the last one.
   */
  const keys = new WeakMap();

  function newKey() {
    if (window.crypto && window.crypto.randomUUID) return window.crypto.randomUUID();
    return 'k-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 12);
  }

  function holderFor(el) {
    // Saves that sit outside a form — a row's delete button, say — share the
    // page's key. They are one-shot actions, and the key is retired as soon
    // as one of them succeeds.
    return (el && el.closest && el.closest('form')) || document.body;
  }

  function keyFor(el) {
    const holder = holderFor(el);
    let key = keys.get(holder);
    if (!key) { key = newKey(); keys.set(holder, key); }
    return { key: key, holder: holder };
  }

  /**
   * `status` is what came back — or 0 when nothing did, because the link
   * dropped or the browser gave up waiting.
   *
   * Retiring the key on *any* outcome was the mistake this replaces, and it
   * defeated the guard in exactly the case it was written for. On a slow link
   * a save reaches the server and is filed, and the answer is lost on the way
   * back. The browser sees a failure, the key is thrown away, the person sees
   * nothing and presses save again — and the second press carries a *new* key,
   * so the server has no way to know it has done this already. Two records.
   *
   * So the key is only retired once an answer has actually arrived:
   *
   *   2xx  the save is known to have landed; the next press is a new
   *        intention and must not be answered from this one.
   *   4xx  the payload was refused. The person will change it and press
   *        again, and that is a different save — holding the key would hand
   *        them back the stored complaint about what they just corrected.
   *   5xx  something broke and the server has already released the key, so
   *        keeping it costs nothing and a retry does the work.
   *   0    nothing came back. The one case where the outcome is genuinely
   *        unknown, and the one where the key has to survive: the retry
   *        carries it, and the server recognises the work it already did.
   */
  /**
   * Say so when a save did not get through.
   *
   * Only for a write somebody pressed a button to start — a background write
   * failing is not something to interrupt them about, and `el` is what says
   * which of the two this was.
   *
   * The wording for a lost answer is careful on purpose. The save may well
   * have been filed; it is the reply that went missing, and telling somebody
   * it failed would be a guess presented as a fact. What can be promised is
   * the part that is now true: pressing save again cannot file it twice,
   * because the retry carries the same key.
   */
  function saveFailed(entry, status) {
    if (!entry || !entry.el || typeof window.showToast !== 'function') return;
    window.showToast('danger', status >= 500
      ? 'The server could not save that. Press Save to try again.'
      : 'No reply from the server — this may or may not have saved. '
        + 'Press Save again; it will not be filed twice.');
  }

  function settle(entry, status) {
    release(entry && entry.el);
    if (!entry || !entry.holder) return;
    const answered = status >= 200 && status < 500;
    if (answered) {
      keys.delete(entry.holder);
    } else {
      // Nothing came back, or the server broke. The button is already usable
      // again; without a word on screen the person sees a save that simply
      // did nothing, which is what makes them press it a second time.
      saveFailed(entry, status);
    }
  }

  // Capture, so the button is known before any handler runs and calls the
  // request that we are about to tie to it.
  document.addEventListener('click', function (event) {
    const el = event.target.closest
      ? event.target.closest('button, input[type="submit"], input[type="button"]')
      : null;
    lastPressed = el && !el.disabled ? el : null;
  }, true);

  function hold(el) {
    if (!el || el.disabled) return null;
    el.disabled = true;
    el.setAttribute('aria-busy', 'true');
    // A cursor rather than a spinner: it needs no markup of its own, so it
    // cannot disturb a layout on four hundred pages.
    el.dataset.bimsCursor = el.style.cursor || '';
    el.style.cursor = 'progress';
    return el;
  }

  function release(el) {
    if (!el) return;
    el.disabled = false;
    el.removeAttribute('aria-busy');
    el.style.cursor = el.dataset.bimsCursor || '';
    delete el.dataset.bimsCursor;
  }

  // Enter in a text box submits the form without anyone clicking anything, so
  // there would be no button to hold and the guard would quietly not apply.
  // `submitter` names the button the browser attributed the submit to; failing
  // that, the form's own submit control is the one to hold. Capture phase, so
  // this lands before the page's handler fires the request.
  document.addEventListener('submit', function (event) {
    const form = event.target;
    if (!form || form.tagName !== 'FORM') return;
    lastPressed = event.submitter || form.querySelector(
      'button[type="submit"], button:not([type]), input[type="submit"]') || lastPressed;
  }, true);

  // jQuery's AJAX, which is how most of the transaction forms save.
  if (window.jQuery) {
    jQuery(document).ajaxSend(function (event, xhr, settings) {
      if (!WRITE.test(settings.type || settings.method || 'GET')) return;
      const pressed = lastPressed;
      const k = keyFor(pressed);
      xhr.setRequestHeader('Idempotency-Key', k.key);
      inFlight.set(xhr, { el: hold(pressed), holder: k.holder });
    });
    jQuery(document).ajaxComplete(function (event, xhr) {
      settle(inFlight.get(xhr), xhr.status || 0);
      inFlight.delete(xhr);
    });
  }

  // fetch(), which the newer forms use.
  const nativeFetch = window.fetch;
  if (typeof nativeFetch === 'function') {
    window.fetch = function (input, init) {
      let method = (init && init.method)
        || (input && typeof input === 'object' && input.method)
        || 'GET';
      if (!WRITE.test(method)) return nativeFetch.apply(this, arguments);

      const k = keyFor(lastPressed);
      // Headers may arrive as a Headers object, an array of pairs or a plain
      // object; normalising is the only way to add to all three. A caller
      // that set the header itself keeps it.
      const opts = Object.assign({}, init);
      const headers = new Headers((init && init.headers)
        || (typeof input === 'object' && input && input.headers) || {});
      if (!headers.has('Idempotency-Key')) headers.set('Idempotency-Key', k.key);
      opts.headers = headers;
      if (init === undefined && typeof input === 'object' && input && input.method) {
        // fetch(new Request(...)) with no init: carry the request's own method
        // through, or the copy would be sent as a GET.
        opts.method = input.method;
      }

      const entry = { el: hold(lastPressed), holder: k.holder };
      let result;
      try {
        result = nativeFetch.call(this, input, opts);
      } catch (e) {
        settle(entry, 0);
        throw e;
      }
      return result.then(
        function (r) { settle(entry, r.status); return r; },
        // No answer at all: the key stays, so the retry is recognised.
        function (e) { settle(entry, 0); throw e; }
      );
    };
  }

  // A form that posts the ordinary way, with no script behind it. Bubble
  // phase and defaultPrevented: a form whose handler called preventDefault is
  // saving over AJAX, and the hooks above already have it. The timeout lets
  // the browser finish serialising the form first — a button disabled any
  // earlier would drop its own name and value from the request.
  document.addEventListener('submit', function (event) {
    if (event.defaultPrevented) return;
    const form = event.target;
    if (!form || form.tagName !== 'FORM') return;

    // No header can be put on a plain form post, so the key travels as a
    // hidden field instead. Added here rather than at page load so it only
    // ever reaches forms that actually post this way — an AJAX form that
    // serialises itself would otherwise carry a field its view never asked
    // for.
    //
    // The key belongs to the form and is never retired on this path, which
    // is what makes it work: the browser resending a POST after a refresh
    // sends the same field back, and so does a person pressing save again on
    // a page that never got its answer. A save that succeeds redirects, and
    // the next page is a new form with a new key.
    if ((form.method || '').toUpperCase() === 'POST') {
      let field = form.querySelector('input[name="idempotency_key"]');
      if (!field) {
        field = document.createElement('input');
        field.type = 'hidden';
        field.name = 'idempotency_key';
        form.appendChild(field);
      }
      field.value = keyFor(form).key;
    }
    setTimeout(function () {
      form.querySelectorAll(
        'button[type="submit"], button:not([type]), input[type="submit"]'
      ).forEach(hold);
    }, 0);
  });
})();

// ---------------------------------------------------------------------------
// Navbar check in/out.
//
// hr/templates/self_attendance.html has the full page with the same camera
// capture flow; this is that same action reachable from every page, for the
// two things most people open the page for — punching in and out — without
// a trip to My Attendance. Reading its own status, so it is correct from the
// very first click even if the page was left open since before midnight.
// ---------------------------------------------------------------------------
(function () {
  const wrap = document.getElementById('navAttendanceWrap');
  if (!wrap) return;

  // CSRF_COOKIE_HTTPONLY is on (settings.py), so the csrftoken cookie is
  // deliberately unreadable from script — same reason the page's own
  // {{ csrf_token }} is read from a data attribute rather than the cookie.
  function getCsrfToken() {
    return wrap.dataset.csrf || '';
  }

  const checkInBtn = document.getElementById('navCheckInBtn');
  const checkOutBtn = document.getElementById('navCheckOutBtn');
  const statusEl = document.getElementById('navAttendanceStatus');
  const modalEl = document.getElementById('navCameraModal');
  const video = document.getElementById('navCameraVideo');
  const canvas = document.getElementById('navCameraCanvas');
  const preview = document.getElementById('navCameraPreview');
  const captureBtn = document.getElementById('navCameraCapture');
  const skipBtn = document.getElementById('navCameraSkip');
  const fallback = document.getElementById('navCameraFallback');

  let checkedIn = wrap.dataset.checkedIn === '1';
  let checkedOut = wrap.dataset.checkedOut === '1';
  const blocked = wrap.dataset.blocked === '1';

  let isCheckIn = true;
  let cameraStream = null, streamWatchdog = null, capturedBlob = null;
  let capturedLat = null, capturedLng = null, capturedAccuracy = null, capturedAddress = '';
  let wizMap = null, wizMarker = null;

  // Check In disables once used (or once a prior day is left open), Check
  // Out disables until checked in (or once used) — both are plain booleans
  // that match server state exactly, so this runs on every load.
  function applyButtons() {
    checkInBtn.disabled = checkedIn || blocked;
    checkOutBtn.disabled = !checkedIn || checkedOut;
  }
  applyButtons();

  // The status badge is left exactly as the server rendered it on page
  // load -- Present/Half Day/Late In only becomes knowable once the day is
  // closed out (hr.views._self_attendance_row), and re-deriving the simpler
  // "Checked Out" here on every load was overwriting that correct label with
  // a wrong one. This only ever runs after a client-side check-in, where
  // "Checked In" is the whole story and there is nothing left to get wrong.
  function applyCheckedInStatus() {
    statusEl.classList.remove('na-checked-in', 'na-blocked');
    statusEl.classList.add('na-checked-in');
    statusEl.textContent = 'Checked In';
  }

  function fmtNow() {
    return new Date().toLocaleString('en-IN', {
      day: '2-digit', month: 'short', year: 'numeric',
      hour: '2-digit', minute: '2-digit', hour12: true,
    });
  }

  function qs(id) { return document.getElementById(id); }

  function goToStep(step) {
    modalEl.querySelectorAll('.sa-wiz-step').forEach(el => el.classList.remove('is-active', 'is-done'));
    modalEl.querySelectorAll('.sa-wiz-pane').forEach(el => el.classList.remove('is-active'));
    const order = ['location', 'selfie', 'confirm', 'success'];
    const idx = order.indexOf(step);
    order.forEach((name, i) => {
      const el = modalEl.querySelector(`.sa-wiz-step[data-step="${name}"]`);
      if (!el) return;
      if (i < idx) el.classList.add('is-done');
      else if (i === idx) el.classList.add('is-active');
    });
    modalEl.querySelector(`.sa-wiz-pane[data-pane="${step}"]`).classList.add('is-active');

    const footerBtns = ['navWizCancel', 'navWizBack', 'navCameraSkip', 'navCameraCapture',
                        'navWizContinue', 'navWizConfirmSubmit', 'navWizClose'];
    footerBtns.forEach(id => qs(id).classList.add('d-none'));

    if (step === 'location') {
      qs('navWizTitle').textContent = isCheckIn ? 'Check In' : 'Check Out';
      qs('navWizCancel').classList.remove('d-none');
      const cont = qs('navWizContinue');
      cont.classList.remove('d-none'); cont.disabled = true;
    } else if (step === 'selfie') {
      qs('navWizTitle').textContent = 'Step 2: Take a Selfie';
      qs('navWizBack').classList.remove('d-none');
      skipBtn.classList.remove('d-none');
      captureBtn.classList.remove('d-none');
    } else if (step === 'confirm') {
      qs('navWizTitle').textContent = 'Step 3: Confirm ' + (isCheckIn ? 'Check In' : 'Check Out');
      qs('navWizBack').classList.remove('d-none');
      const submitBtn = qs('navWizConfirmSubmit');
      submitBtn.classList.remove('d-none');
      submitBtn.textContent = isCheckIn ? 'Confirm Check In' : 'Confirm Check Out';
      qs('navWizConfirmWhen').textContent = fmtNow();
      qs('navWizConfirmLoc').textContent = capturedAddress ||
        (capturedLat != null ? `${capturedLat.toFixed(5)}, ${capturedLng.toFixed(5)}` : '-');
      const photoEl = qs('navWizConfirmPhoto');
      if (capturedBlob) { photoEl.src = preview.src; photoEl.classList.remove('d-none'); }
      else { photoEl.classList.add('d-none'); }
    } else if (step === 'success') {
      qs('navWizClose').classList.remove('d-none');
    }
  }

  function initWizMap(lat, lng) {
    if (typeof L === 'undefined') return;
    if (!wizMap) {
      wizMap = L.map('navWizMap', { zoomControl: false, attributionControl: false }).setView([lat, lng], 16);
      L.tileLayer(BIMS_MAP.url, {
        maxZoom: BIMS_MAP.maxZoom, attribution: BIMS_MAP.attribution,
      }).addTo(wizMap);
      wizMarker = L.marker([lat, lng]).addTo(wizMap);
    } else {
      wizMap.setView([lat, lng], 16);
      wizMarker.setLatLng([lat, lng]);
    }
    setTimeout(() => wizMap.invalidateSize(), 150);
  }

  function captureLocation() {
    const statusEl = qs('navWizLocStatus');
    statusEl.classList.remove('d-none');
    statusEl.innerHTML = '<span class="spinner-border spinner-border-sm text-success"></span><span>Getting your GPS location…</span>';
    qs('navWizLocDetail').classList.add('d-none');
    qs('navWizLocRetry').classList.add('d-none');
    qs('navWizContinue').disabled = true;
    if (!navigator.geolocation) {
      statusEl.innerHTML = '<span class="text-danger">Location is not available in this browser.</span>';
      return;
    }
    navigator.geolocation.getCurrentPosition(
      pos => {
        capturedLat = pos.coords.latitude;
        capturedLng = pos.coords.longitude;
        capturedAccuracy = pos.coords.accuracy;
        initWizMap(capturedLat, capturedLng);
        qs('navWizLocCoords').textContent = `${capturedLat.toFixed(5)}, ${capturedLng.toFixed(5)}`;
        qs('navWizLocAccuracy').textContent = Math.round(capturedAccuracy) + ' meters';
        qs('navWizLocAddress').textContent = 'Looking up address…';
        statusEl.innerHTML = '<span class="text-success"><i class="fas fa-check-circle me-1"></i>Location captured</span>';
        qs('navWizLocDetail').classList.remove('d-none');
        qs('navWizContinue').disabled = false;
        if (window.reverseGeocode) {
          window.reverseGeocode(capturedLat.toFixed(6), capturedLng.toFixed(6)).then(place => {
            capturedAddress = place && place.display ? place.display : '';
            qs('navWizLocAddress').textContent = capturedAddress || '-';
          }).catch(() => { qs('navWizLocAddress').textContent = '-'; });
        } else {
          qs('navWizLocAddress').textContent = '-';
        }
      },
      err => {
        capturedLat = capturedLng = capturedAccuracy = null;
        const msg = err && err.code === err.PERMISSION_DENIED
          ? 'Location access was denied. Allow it in your browser settings and retry.'
          : 'Could not read your location. Check your connection and retry.';
        statusEl.innerHTML = `<span class="text-danger"><i class="fas fa-triangle-exclamation me-1"></i>${msg}</span>`;
        qs('navWizLocRetry').classList.remove('d-none');
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  }

  qs('navWizLocRetry').addEventListener('click', captureLocation);

  function stopCamera() {
    if (cameraStream) { cameraStream.getTracks().forEach(t => t.stop()); cameraStream = null; }
    if (streamWatchdog) { clearTimeout(streamWatchdog); streamWatchdog = null; }
  }

  function resetCameraPane() {
    video.style.display = ''; preview.style.display = 'none'; fallback.classList.add('d-none');
    capturedBlob = null;
    captureBtn.classList.remove('d-none'); captureBtn.disabled = true;
  }

  // A granted permission does not guarantee real frames — a virtual/blocked
  // device can open a stream that never produces a picture, which is the
  // black square a dead camera shows. Capture stays disabled until the video
  // actually reports a size, and a 3s watchdog gives up and offers Skip
  // Photo rather than leave a frozen preview with no way forward.
  function showCameraFallback() {
    if (streamWatchdog) { clearTimeout(streamWatchdog); streamWatchdog = null; }
    video.style.display = 'none';
    fallback.classList.remove('d-none');
    captureBtn.classList.add('d-none');
  }

  video.addEventListener('loadeddata', function () {
    if (streamWatchdog) { clearTimeout(streamWatchdog); streamWatchdog = null; }
    captureBtn.disabled = false;
  });
  // A dead/disconnected device can fire 'error' on the <video> element
  // directly rather than ever resolving loadeddata — no reason to wait
  // out the watchdog when the browser has already said so.
  video.addEventListener('error', showCameraFallback);

  function openCamera() {
    resetCameraPane();
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      showCameraFallback();
      return;
    }
    navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } })
      .then(stream => {
        cameraStream = stream;
        video.srcObject = stream;
        streamWatchdog = setTimeout(() => {
          if (!video.videoWidth) showCameraFallback();
        }, 3000);
      })
      .catch(showCameraFallback);
  }

  captureBtn.addEventListener('click', function () {
    canvas.width = video.videoWidth; canvas.height = video.videoHeight;
    canvas.getContext('2d').drawImage(video, 0, 0);
    preview.src = canvas.toDataURL('image/jpeg', 0.85);
    video.style.display = 'none'; preview.style.display = '';
    canvas.toBlob(blob => {
      capturedBlob = blob;
      stopCamera();
      goToStep('confirm');
    }, 'image/jpeg', 0.85);
  });

  skipBtn.addEventListener('click', function () {
    stopCamera();
    capturedBlob = null;
    goToStep('confirm');
  });

  qs('navWizContinue').addEventListener('click', function () {
    goToStep('selfie');
    openCamera();
  });

  qs('navWizBack').addEventListener('click', function () {
    const current = modalEl.querySelector('.sa-wiz-pane.is-active').dataset.pane;
    if (current === 'selfie') { stopCamera(); goToStep('location'); }
    else if (current === 'confirm') { goToStep('selfie'); openCamera(); }
  });

  qs('navWizConfirmSubmit').addEventListener('click', function () {
    const btn = qs('navWizConfirmSubmit');
    btn.disabled = true;
    const url = isCheckIn ? wrap.dataset.checkinUrl : wrap.dataset.checkoutUrl;
    const fd = new FormData();
    fd.append('latitude', capturedLat);
    fd.append('longitude', capturedLng);
    if (capturedBlob) fd.append('photo', capturedBlob, 'selfie.jpg');
    fetch(url, { method: 'POST', headers: { 'X-CSRFToken': getCsrfToken() }, body: fd })
      .then(async r => {
        const body = await r.json().catch(() => ({}));
        if (!r.ok) throw new Error(body.error || 'Failed.');
        const when = [body.date, body.time].filter(Boolean).join(', ');
        qs('navWizSuccessTitle').textContent = (isCheckIn ? 'Checked In' : 'Checked Out') + ' Successfully!';
        qs('navWizSuccessWhen').textContent = when;
        qs('navWizSuccessLoc').textContent = capturedAddress || '';
        if (isCheckIn) { checkedIn = true; applyCheckedInStatus(); }
        else { checkedOut = true; }
        goToStep('success');
      })
      .catch(err => {
        window.showToast('danger', err.message);
        btn.disabled = false;
      });
  });

  modalEl.addEventListener('hidden.bs.modal', function () {
    stopCamera();
    const succeeded = modalEl.querySelector('.sa-wiz-pane[data-pane="success"]').classList.contains('is-active');
    applyButtons();
    capturedBlob = null;
    capturedLat = capturedLng = capturedAccuracy = null; capturedAddress = '';
    if (succeeded && !isCheckIn) {
      // Present / Half Day / Late In can only be told apart once the day is
      // complete, and that comparison against the shift lives server-side
      // (hr.views._self_attendance_row) — a reload is what lets the real
      // label replace the generic status rather than re-deriving the same
      // rule a second time here.
      setTimeout(() => window.location.reload(), 300);
    }
  });

  function openWizard(checkIn) {
    isCheckIn = checkIn;
    goToStep('location');
    const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
    modal.show();
    captureLocation();
  }

  checkInBtn.addEventListener('click', function () {
    if (blocked) { window.location.href = wrap.dataset.pageUrl; return; }
    checkInBtn.disabled = true;
    openWizard(true);
  });

  checkOutBtn.addEventListener('click', function () {
    checkOutBtn.disabled = true;
    openWizard(false);
  });

  statusEl.addEventListener('click', function () {
    window.location.href = wrap.dataset.pageUrl;
  });
})();

/* Paste and drag-drop for file inputs.
 *
 * A file input opts in with data-paste-drop. The browse button keeps
 * working exactly as before; this only adds two more ways to put the same
 * files into it:
 *
 *   - paste (Ctrl+V) anywhere on the page while the input's card or modal
 *     is the thing on screen, which is how a screenshot gets attached
 *     without first being saved to disk;
 *   - dropping files onto the input or its drop zone.
 *
 * Both go through the input's own .files via a DataTransfer, so whatever
 * reads the input on submit -- a form post, FormData, a change handler --
 * sees exactly what it would have seen from the file picker, and the
 * input's own accept/multiple attributes still decide what is allowed.
 */
(function () {
  function accepts(input, file) {
    const accept = (input.getAttribute('accept') || '').trim();
    if (!accept) return true;
    const type = (file.type || '').toLowerCase();
    const name = (file.name || '').toLowerCase();
    return accept.split(',').some(function (rule) {
      rule = rule.trim().toLowerCase();
      if (!rule) return false;
      if (rule.endsWith('/*')) return type.startsWith(rule.slice(0, -1));
      if (rule.startsWith('.')) return name.endsWith(rule);
      return type === rule;
    });
  }

  // A pasted screenshot arrives as a blob named "image.png", so several in
  // a row would be indistinguishable in the file list. Stamping the name
  // keeps them apart and makes it obvious where the file came from.
  let pasteSeq = 0;
  function named(file) {
    if (file.name && file.name !== 'image.png' && file.name !== 'blob') return file;
    const ext = (file.type.split('/')[1] || 'png').replace('jpeg', 'jpg');
    const now = new Date();
    const stamp = now.toISOString().slice(0, 19).replace(/[:T]/g, '-');
    // The counter matters: two screenshots pasted inside the same second
    // would otherwise be handed over under one name, and a server that
    // keys on filename would keep only the last.
    pasteSeq += 1;
    return new File([file], 'pasted-' + stamp + '-' + pasteSeq + '.' + ext,
                    { type: file.type });
  }

  function addFiles(input, files) {
    const keep = [];
    const multiple = input.multiple;
    // Adding to what is already there, not replacing it: pasting a second
    // screenshot into a multi-file input should leave the first attached.
    if (multiple) for (let i = 0; i < input.files.length; i++) keep.push(input.files[i]);

    let added = 0;
    for (let i = 0; i < files.length; i++) {
      if (!accepts(input, files[i])) continue;
      keep.push(named(files[i]));
      added++;
      if (!multiple) break;
    }
    if (!added) return 0;

    const dt = new DataTransfer();
    (multiple ? keep : keep.slice(-1)).forEach(function (f) { dt.items.add(f); });
    input.files = dt.files;
    // Anything already listening for a pick hears this the same way.
    input.dispatchEvent(new Event('change', { bubbles: true }));
    return added;
  }

  function flash(input, text) {
    let note = input.parentNode.querySelector('.paste-drop-note');
    if (!note) {
      note = document.createElement('div');
      note.className = 'form-text paste-drop-note';
      input.parentNode.appendChild(note);
    }
    note.textContent = text;
    note.style.color = '#1a7f45';
    clearTimeout(note._t);
    note._t = setTimeout(function () { note.textContent = ''; }, 4000);
  }

  /* Thumbnails of whatever is currently on the input.
   *
   * A file input shows "3 files" and nothing else, which is no use when the
   * files arrived by paste: a screenshot has no meaningful name to check,
   * so the only way to know the right thing is attached is to see it.
   * Rebuilt from input.files on every change, so it is as true for a file
   * picked through Browse as for one pasted or dropped.
   *
   * Each thumbnail carries a remove button. Removing rewrites input.files
   * through a DataTransfer, the same way files are added -- which is the
   * only way to drop one file from a selection, since a file input cannot
   * be edited in place.
   */
  function fileIcon(file) {
    const type = (file.type || '').toLowerCase();
    if (type === 'application/pdf') return 'fa-file-pdf';
    if (type.startsWith('video/')) return 'fa-file-video';
    if (type.startsWith('audio/')) return 'fa-file-audio';
    if (/sheet|excel|csv/.test(type)) return 'fa-file-excel';
    if (/word|document/.test(type)) return 'fa-file-word';
    return 'fa-file';
  }

  function humanSize(n) {
    if (n < 1024) return n + ' B';
    if (n < 1024 * 1024) return Math.round(n / 1024) + ' KB';
    return (n / (1024 * 1024)).toFixed(1) + ' MB';
  }

  function removeAt(input, index) {
    const dt = new DataTransfer();
    for (let i = 0; i < input.files.length; i++) {
      if (i !== index) dt.items.add(input.files[i]);
    }
    input.files = dt.files;
    input.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function clearAll(input) {
    // An empty DataTransfer rather than input.value = '': both empty the
    // input, but this keeps the one path for changing a selection, and the
    // change event below is what redraws the thumbnails.
    input.files = new DataTransfer().files;
    input.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function renderThumbs(input) {
    let wrap = input.parentNode.querySelector('.paste-drop-thumbs');
    if (!wrap) {
      wrap = document.createElement('div');
      wrap.className = 'paste-drop-thumbs';
      // After the input, but before the hint text and the flash note, so
      // the order reads: control, what is attached, then guidance.
      input.parentNode.insertBefore(wrap, input.nextSibling);
    }
    // Object URLs hold the file in memory until revoked, and this redraws
    // on every change.
    (wrap._urls || []).forEach(function (u) { URL.revokeObjectURL(u); });
    wrap._urls = [];
    wrap.innerHTML = '';
    if (!input.files.length) { wrap.style.display = 'none'; return; }
    wrap.style.display = '';

    Array.prototype.forEach.call(input.files, function (file, i) {
      const cell = document.createElement('div');
      cell.className = 'paste-drop-thumb';
      cell.title = file.name + ' — ' + humanSize(file.size);

      if ((file.type || '').startsWith('image/')) {
        const url = URL.createObjectURL(file);
        wrap._urls.push(url);
        const img = document.createElement('img');
        img.src = url;
        img.alt = file.name;
        cell.appendChild(img);
      } else {
        const ic = document.createElement('i');
        ic.className = 'fas ' + fileIcon(file);
        cell.appendChild(ic);
      }

      const cap = document.createElement('span');
      cap.className = 'paste-drop-thumb-name';
      cap.textContent = file.name;
      cell.appendChild(cap);

      const del = document.createElement('button');
      del.type = 'button';           // never submits the form it sits in
      del.className = 'paste-drop-thumb-x';
      del.setAttribute('aria-label', 'Remove ' + file.name);
      del.innerHTML = '&times;';
      del.addEventListener('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        removeAt(input, i);
      });
      cell.appendChild(del);

      wrap.appendChild(cell);
    });

    // Only worth offering once there is more than one file to clear --
    // with a single thumbnail its own x is right there and says the same
    // thing.
    if (input.files.length > 1) {
      const clear = document.createElement('button');
      clear.type = 'button';
      clear.className = 'paste-drop-clear';
      clear.textContent = 'Clear all (' + input.files.length + ')';
      clear.addEventListener('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        clearAll(input);
      });
      wrap.appendChild(clear);
    }
  }

  // The drop target, widest first. closest() with a comma list returns the
  // NEAREST match, which inside a dialog is the <form> -- so a file dropped
  // on the dialog's own padding or header landed nowhere, and the highlight
  // only ever covered the form. A dialog is the thing on screen, so the
  // whole of it takes the drop.
  function zoneFor(input) {
    return input.closest('.modal-content')
        || input.closest('form, .card')
        || input.parentNode;
  }

  /* The visible drop zone.
   *
   * A bare file input reads "Choose Files / No file chosen", which says
   * nothing about dragging or pasting -- the two ways most of these files
   * actually arrive. The input is kept (it is still what carries the files
   * and what the form submits) but moved out of sight behind a panel that
   * states all three routes and is clickable across its whole area.
   *
   * Opt out with data-paste-drop="plain" where the inline control has to
   * stay, such as a toolbar row with no room for a panel.
   */
  function buildZoneUI(input) {
    if (input.dataset.pasteDrop === 'plain') return null;
    const panel = document.createElement('div');
    panel.className = 'paste-drop-panel';
    panel.innerHTML =
      '<i class="fas fa-cloud-arrow-up"></i>' +
      '<span class="paste-drop-panel-main">Drag files here or <u>click to browse</u></span>' +
      '<span class="paste-drop-panel-sub">or paste a screenshot with Ctrl+V</span>';
    input.parentNode.insertBefore(panel, input);
    input.classList.add('paste-drop-hidden-input');
    // Clicking the panel opens the same picker the input would.
    panel.addEventListener('click', function () { input.click(); });
    // Keyboard: the panel stands in for the input, so it has to be reachable
    // and operable without a mouse.
    panel.tabIndex = 0;
    panel.setAttribute('role', 'button');
    panel.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); input.click(); }
    });
    return panel;
  }

  function wire(input) {
    if (input._pasteDropWired) return;
    input._pasteDropWired = true;

    input._panel = buildZoneUI(input);

    // One listener covers every route in: Browse fires change natively,
    // and paste/drop fire it through addFiles().
    input.addEventListener('change', function () { renderThumbs(input); });
    renderThumbs(input);
    // A form reset (Bootstrap's modals reset theirs on close) empties the
    // input without firing change, which would leave stale thumbnails
    // behind for the next time the dialog opens.
    const owner = input.form;
    if (owner) {
      owner.addEventListener('reset', function () {
        setTimeout(function () { renderThumbs(input); }, 0);
      });
    }

    const zone = zoneFor(input);

    ['dragenter', 'dragover'].forEach(function (ev) {
      zone.addEventListener(ev, function (e) {
        if (!e.dataTransfer || !Array.from(e.dataTransfer.types || []).includes('Files')) return;
        e.preventDefault();
        zone.classList.add('paste-drop-over');
        if (input._panel) input._panel.classList.add('paste-drop-panel-over');
      });
    });
    ['dragleave', 'drop'].forEach(function (ev) {
      zone.addEventListener(ev, function (e) {
        if (ev === 'dragleave' && zone.contains(e.relatedTarget)) return;
        zone.classList.remove('paste-drop-over');
        if (input._panel) input._panel.classList.remove('paste-drop-panel-over');
      });
    });
    zone.addEventListener('drop', function (e) {
      if (!e.dataTransfer || !e.dataTransfer.files.length) return;
      e.preventDefault();
      const n = addFiles(input, e.dataTransfer.files);
      if (n) flash(input, n + ' file' + (n > 1 ? 's' : '') + ' added.');
    });

    // Paste is a document-level event: it lands wherever the caret is, not
    // on the file input, which cannot hold focus in the usual sense. Only
    // the visible input takes it, so a page with several does not attach
    // the same screenshot to all of them.
    document.addEventListener('paste', function (e) {
      if (!e.clipboardData || !e.clipboardData.files || !e.clipboardData.files.length) return;
      const target = e.target;
      if (target && /^(INPUT|TEXTAREA)$/.test(target.tagName) && target.type !== 'file') return;
      if (!input.offsetParent) return;
      const openModal = document.querySelector('.modal.show');
      if (openModal && !openModal.contains(input)) return;
      if (!openModal && input.closest('.modal')) return;
      const n = addFiles(input, e.clipboardData.files);
      if (n) {
        e.preventDefault();
        flash(input, n + ' file' + (n > 1 ? 's' : '') + ' pasted.');
      }
    });
  }

  function wireAll(root) {
    (root || document).querySelectorAll('input[type="file"][data-paste-drop]').forEach(wire);
  }

  document.addEventListener('DOMContentLoaded', function () {
    wireAll();
    // Modals and rows that arrive after load (the evidence and attachment
    // dialogs are rendered with the page but others are not).
    new MutationObserver(function (muts) {
      muts.forEach(function (m) {
        m.addedNodes.forEach(function (n) {
          if (n.nodeType !== 1) return;
          if (n.matches && n.matches('input[type="file"][data-paste-drop]')) wire(n);
          else if (n.querySelectorAll) wireAll(n);
        });
      });
    }).observe(document.body, { childList: true, subtree: true });
  });
})();

/* Image editor: crop + rotate before upload.
 *
 * Any file input with data-paste-drop and data-image-edit (or just
 * data-image-edit on its own) opens an editor modal when an image is
 * picked, pasted, or dropped. The user can crop and rotate; on confirm
 * the cropped blob replaces the original in the input. PDFs and
 * non-images skip the editor.
 *
 * Requires Cropper.js to be loaded before this script.
 */
(function () {
  if (typeof Cropper === 'undefined') return;

  var modal, img, cropper, resolveEdit, rejectEdit;

  function buildModal() {
    var div = document.createElement('div');
    div.innerHTML =
      '<div class="modal fade" id="bimsImageEditor" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">' +
        '<div class="modal-dialog modal-lg modal-dialog-centered">' +
          '<div class="modal-content">' +
            '<div class="modal-header py-2">' +
              '<h6 class="modal-title"><i class="fas fa-crop-simple me-1"></i>Edit Image</h6>' +
              '<button type="button" class="btn-close" data-bs-dismiss="modal"></button>' +
            '</div>' +
            '<div class="modal-body p-0" style="background:#1a1a2e">' +
              '<img id="bimsEditorImg" style="display:block;max-width:100%">' +
            '</div>' +
            '<div class="modal-footer py-2 justify-content-between">' +
              '<div class="d-flex gap-2">' +
                '<button type="button" class="btn btn-sm btn-outline-light bims-ed-rotate" data-deg="-90" title="Rotate left"><i class="fas fa-rotate-left"></i></button>' +
                '<button type="button" class="btn btn-sm btn-outline-light bims-ed-rotate" data-deg="90" title="Rotate right"><i class="fas fa-rotate-right"></i></button>' +
                '<button type="button" class="btn btn-sm btn-outline-light bims-ed-flip-h" title="Flip horizontal"><i class="fas fa-arrows-left-right"></i></button>' +
                '<button type="button" class="btn btn-sm btn-outline-light bims-ed-flip-v" title="Flip vertical"><i class="fas fa-arrows-up-down"></i></button>' +
                '<button type="button" class="btn btn-sm btn-outline-light bims-ed-reset" title="Reset"><i class="fas fa-undo"></i></button>' +
              '</div>' +
              '<div class="d-flex gap-2">' +
                '<button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">Skip</button>' +
                '<button type="button" class="btn btn-sm btn-primary bims-ed-apply"><i class="fas fa-check me-1"></i>Apply</button>' +
              '</div>' +
            '</div>' +
          '</div>' +
        '</div>' +
      '</div>';
    document.body.appendChild(div.firstChild);
    modal = document.getElementById('bimsImageEditor');
    img = document.getElementById('bimsEditorImg');

    modal.querySelectorAll('.bims-ed-rotate').forEach(function (btn) {
      btn.addEventListener('click', function () {
        if (cropper) cropper.rotate(parseInt(this.dataset.deg));
      });
    });
    modal.querySelector('.bims-ed-flip-h').addEventListener('click', function () {
      if (cropper) {
        var d = cropper.getData();
        cropper.scaleX(d.scaleX === -1 ? 1 : -1);
      }
    });
    modal.querySelector('.bims-ed-flip-v').addEventListener('click', function () {
      if (cropper) {
        var d = cropper.getData();
        cropper.scaleY(d.scaleY === -1 ? 1 : -1);
      }
    });
    modal.querySelector('.bims-ed-reset').addEventListener('click', function () {
      if (cropper) cropper.reset();
    });
    modal.querySelector('.bims-ed-apply').addEventListener('click', function () {
      if (!cropper) return;
      var canvas = cropper.getCroppedCanvas({ maxWidth: 4096, maxHeight: 4096 });
      canvas.toBlob(function (blob) {
        if (resolveEdit) resolveEdit(blob);
        bootstrap.Modal.getInstance(modal).hide();
      }, 'image/jpeg', 0.92);
    });
    modal.addEventListener('hidden.bs.modal', function () {
      if (cropper) { cropper.destroy(); cropper = null; }
      if (rejectEdit) { rejectEdit('skip'); rejectEdit = null; }
    });
  }

  function editImage(file) {
    return new Promise(function (resolve, reject) {
      if (!modal) buildModal();
      resolveEdit = function (blob) {
        resolveEdit = null; rejectEdit = null;
        resolve(blob);
      };
      rejectEdit = function (reason) {
        rejectEdit = null; resolveEdit = null;
        reject(reason);
      };
      var url = URL.createObjectURL(file);
      img.onload = function () {
        URL.revokeObjectURL(url);
        cropper = new Cropper(img, {
          viewMode: 1,
          autoCropArea: 1,
          responsive: true,
          restore: false,
          background: false,
        });
      };
      img.src = url;
      new bootstrap.Modal(modal).show();
    });
  }

  async function processFiles(input) {
    var files = Array.from(input.files);
    if (!files.length) return;
    var changed = false;
    var result = [];

    for (var i = 0; i < files.length; i++) {
      var f = files[i];
      if (!(f.type || '').startsWith('image/')) { result.push(f); continue; }
      try {
        var blob = await editImage(f);
        var ext = 'jpg';
        var newName = f.name.replace(/\.[^.]+$/, '') + '-edited.' + ext;
        result.push(new File([blob], newName, { type: 'image/jpeg' }));
        changed = true;
      } catch (e) {
        result.push(f);
      }
    }

    if (changed) {
      var dt = new DataTransfer();
      result.forEach(function (f) { dt.items.add(f); });
      input._skipEdit = true;
      input.files = dt.files;
      input.dispatchEvent(new Event('change', { bubbles: true }));
    }
  }

  function wireEditor(input) {
    if (input._imageEditWired) return;
    input._imageEditWired = true;

    input.addEventListener('change', function () {
      if (input._skipEdit) { input._skipEdit = false; return; }
      var hasImage = Array.from(input.files).some(function (f) {
        return (f.type || '').startsWith('image/');
      });
      if (hasImage) {
        setTimeout(function () { processFiles(input); }, 100);
      }
    });
  }

  function wireAll(root) {
    (root || document).querySelectorAll('input[type="file"][data-paste-drop]').forEach(wireEditor);
  }

  document.addEventListener('DOMContentLoaded', function () {
    wireAll();
    new MutationObserver(function (muts) {
      muts.forEach(function (m) {
        m.addedNodes.forEach(function (n) {
          if (n.nodeType !== 1) return;
          if (n.matches && n.matches('input[type="file"][data-paste-drop]')) wireEditor(n);
          else if (n.querySelectorAll) wireAll(n);
        });
      });
    }).observe(document.body, { childList: true, subtree: true });
  });

  window.BIMS_ImageEditor = { edit: editImage };
})();

/* Mobile paste zone.
 *
 * On mobile browsers, pasting an image into a file input is not possible.
 * A contenteditable div accepts long-press → Paste on both Android and
 * iOS, and the pasted image can be extracted from the paste event's
 * clipboardData and fed into the nearest file input.
 *
 * Injected into every upload modal that has a data-paste-drop file input,
 * only on touch devices.
 */
(function () {
  var isTouch = ('ontouchstart' in window) || (navigator.maxTouchPoints > 0);
  if (!isTouch) return;

  function buildPasteZone(input) {
    if (input._mobilePasteZone) return;
    var zone = document.createElement('div');
    zone.className = 'mobile-paste-zone';
    zone.contentEditable = 'true';
    zone.setAttribute('role', 'textbox');
    zone.setAttribute('aria-label', 'Long-press here to paste an image');
    zone.innerHTML = '<i class="fas fa-paste"></i> Long-press here to paste an image';

    zone.addEventListener('paste', function (e) {
      e.preventDefault();
      var items = (e.clipboardData || {}).items;
      if (!items) return;
      var files = [];
      for (var i = 0; i < items.length; i++) {
        if (items[i].kind === 'file') {
          var f = items[i].getAsFile();
          if (f) files.push(f);
        }
      }
      zone.innerHTML = '<i class="fas fa-paste"></i> Long-press here to paste an image';
      if (!files.length) return;

      var dt = new DataTransfer();
      if (input.multiple) {
        for (var j = 0; j < input.files.length; j++) dt.items.add(input.files[j]);
      }
      files.forEach(function (f) {
        var ext = (f.type.split('/')[1] || 'png').replace('jpeg', 'jpg');
        var stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
        var named = new File([f], 'pasted-' + stamp + '.' + ext, { type: f.type });
        dt.items.add(named);
      });
      input.files = dt.files;
      input.dispatchEvent(new Event('change', { bubbles: true }));

      var note = input.parentNode.querySelector('.paste-drop-note');
      if (!note) {
        note = document.createElement('div');
        note.className = 'form-text paste-drop-note';
        input.parentNode.appendChild(note);
      }
      note.textContent = files.length + ' file' + (files.length > 1 ? 's' : '') + ' pasted.';
      note.style.color = '#1a7f45';
      clearTimeout(note._t);
      note._t = setTimeout(function () { note.textContent = ''; }, 4000);
    });

    zone.addEventListener('input', function () {
      var imgs = zone.querySelectorAll('img');
      if (imgs.length) {
        imgs.forEach(function (i) { i.remove(); });
      }
      if (zone.textContent.trim() !== '') {
        zone.innerHTML = '<i class="fas fa-paste"></i> Long-press here to paste an image';
      }
    });

    input.parentNode.insertBefore(zone, input.nextSibling);
    input._mobilePasteZone = zone;
  }

  function wireAll(root) {
    (root || document).querySelectorAll('input[type="file"][data-paste-drop]').forEach(buildPasteZone);
  }

  document.addEventListener('DOMContentLoaded', function () {
    wireAll();
    new MutationObserver(function (muts) {
      muts.forEach(function (m) {
        m.addedNodes.forEach(function (n) {
          if (n.nodeType !== 1) return;
          if (n.matches && n.matches('input[type="file"][data-paste-drop]')) buildPasteZone(n);
          else if (n.querySelectorAll) wireAll(n);
        });
      });
    }).observe(document.body, { childList: true, subtree: true });
  });
})();
